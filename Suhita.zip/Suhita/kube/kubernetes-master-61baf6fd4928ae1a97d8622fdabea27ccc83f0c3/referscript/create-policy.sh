#!/bin/bash
# Vault Configuration
Vault_Pod=$(kubectl get pods --namespace devops -l "app=vault" -o jsonpath="{.items[0].metadata.name}")
VAULT_TOKEN=$(kubectl logs $Vault_Pod -n devops | grep 'Root Token' | cut -d' ' -f3)
Master_IP=$(kubectl get nodes -owide | awk '/master/{print $6}')
echo "Root token is: "$VAULT_TOKEN
VAULT_ADDR=http://$Master_IP:30030

# Install jq
yum update -y
yum install -y jq

#echo -n "Enter path for the secret:"
#read Path
# Add Mount
curl -s -X POST -H "X-Vault-Token:$VAULT_TOKEN" -d '{"type":"generic","path":"cred"}' http://$Master_IP:30030/v1/sys/mounts/cred
echo "Mounted the path successfully!"
# Create policy
#echo -n "Enter Policy name:"
#read Pname

curl  --header "X-Vault-Token: $VAULT_TOKEN"  --request PUT -d '{"rules": "path \"cred/*\" { capabilities=[\"read\",\"create\",\"update\",\"delete\",\"list\"] }"}' http://$Master_IP:30030/v1/sys/policy/Pname1
echo "Created the policy"
# Create approle
curl -X POST -H "X-Vault-Token:$VAULT_TOKEN" -d '{"type":"approle"}' http://$Master_IP:30030/v1/sys/auth/approle

# Create TestRole
curl -X POST -H "X-Vault-Token:$VAULT_TOKEN" -d '{"policies":"Pname1"}' http://$Master_IP:30030/v1/auth/approle/role/testrole

# Get Role-ID
Role_ID=$(curl -s -X GET -H "X-Vault-Token:$VAULT_TOKEN" http://$Master_IP:30030/v1/auth/approle/role/testrole/role-id | jq -r '.data.role_id')

# Get Secret-ID
Secret_ID=$(curl -s -X POST -H "X-Vault-Token:$VAULT_TOKEN" http://$Master_IP:30030/v1/auth/approle/role/testrole/secret-id | jq -r '.data.secret_id')

# Auth AppRole
AppRole_Token=$(curl -s -X POST -d '{"role_id":"$Role_ID","secret_id":"$Secret_ID"}' http://$Master_IP:30030/v1/auth/approle/login | jq -r '.auth.client_token')

echo "Writing Secrets"
#echo -n "Enter path for the secret:"
#read Path1
#echo -n "Enter keys and values in below format:"
#echo -n '''"key1":"value1","key2":"value2",.......:'''
#read KeyValues

#curl -s -X POST -H "X-Vault-Token:$VAULT_TOKEN" -d '{'$KeyValues'}' http://$Master_IP:30030/v1/cred/artifactory
curl -s -X POST -H "X-Vault-Token:$VAULT_TOKEN" -d '{"username":"admin","password":"password"}' http://$Master_IP:30030/v1/cred/artifactory
echo "Default secrets for artifactory are written to the path!"
#echo "Reading a Secret"
#echo -n "Enter the key for secret:"
#read key
#echo "The value is:"
#curl -s -X GET -H "X-Vault-Token:$VAULT_TOKEN" http://$Master_IP:30030/v1/$Path1 | jq -r '.data.'$key
