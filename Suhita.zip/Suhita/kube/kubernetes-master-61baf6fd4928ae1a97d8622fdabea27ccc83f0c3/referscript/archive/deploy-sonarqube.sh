#!/bin/bash

# SET YAMLS PATH FOR SONARQUBE
SONARQUBE=/opt/kubernetes/yamlfiles/sonarqube

# DEPLOY MYSQL DATABASE
kubectl create -f $SONARQUBE/mysql-sts.yaml

# DEPLOY SONARQUBE
kubectl create -f $SONARQUBE/sonar-deployment.yaml
