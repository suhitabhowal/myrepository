#!/bin/bash

# LOG INTO THE MACHINE AS ROOT
sudo -i

# SET VARIABLE TO STORE THE DOCKER IMAGE SERVER
DOCKER_IMAGE_SERVER=api.aigdevopscoe.net:30003

#echo $USERNAME
#echo $PASSWORD
#echo $1
#echo $2

# LOG INTO THE DOCKER IMAGE SERVER
docker login $DOCKER_IMAGE_SERVER -p password -u admin

# CHECK WHETHER CHANGE IS REFLECTED
cat ~/.docker/config.json
