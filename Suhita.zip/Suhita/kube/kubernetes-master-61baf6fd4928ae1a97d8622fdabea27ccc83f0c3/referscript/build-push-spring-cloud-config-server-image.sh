#!/bin/bash
curl https://start.spring.io/starter.tgz -d dependencies=cloud-config-server \
-d groupId=com.server.config -d artifactId=SpringCloudConfig -d baseDir=spring-cloud-config-server \
-d applicationName=SpringCloudConfig | tar -xzvf -
 
 
cd spring-cloud-config-server/src/main/resources
rm application.properties

GITLAB_IP_PORT=52.24.45.135:9090
#echo "GITLAB_IP_PORT is currently '$GITLAB_IP_PORT'. Do you want to change it?"
#echo "If so, type it, else enter 'y' or 'Y'"
#read temp
#if [ "$temp" == "y" ] || [ "$temp" == "Y" ]; then
#	GITLAB_IP_PORT=$GITLAB_IP_PORT
#else
#	GITLAB_IP_PORT=$temp
#fi
echo "GITLAB_IP_PORT set to '$GITLAB_IP_PORT'"
REPO_URL="http://$GITLAB_IP_PORT/test/spring-cloud-config-server-db.git"
#echo "Please ensure that the below repo is ready for use with key-values loaded for projects prpended with 'app'."
#echo "Else, type 'cancel' to cancel this script, create repo and rerun it:"
echo "$REPO_URL"
#read temp
#if [ "$temp" == "cancel" ]; then
#	exit 0
#fi

#echo "Please ensure that the userid, password for this repo are updated in this script"
#echo "Else, type 'cancel' to cancel this script, update and then rerun it:"
#read temp
#if [ "$temp" == "cancel" ]; then
#	exit 0
#fi

#vi application.yml
echo "server:" > application.yml
echo "  port: 8980" >> application.yml
 
echo "spring:" >> application.yml
echo "  cloud:" >> application.yml
echo "    config:" >> application.yml
echo "      server:" >> application.yml
echo "        git:" >> application.yml
echo "          uri: $REPO_URL" >> application.yml
echo "          username: test" >> application.yml
echo "          password: testtest" >> application.yml
echo "          search-paths:" >> application.yml
echo "          - app*" >> application.yml

cd ../../../../
cd spring-cloud-config-server/src/main/java/com/server/config/SpringCloudConfig
#vi SpringCloudConfig.java
echo "package com.server.config.SpringCloudConfig;" > SpringCloudConfig.java
echo " " >> SpringCloudConfig.java
echo "import org.springframework.boot.SpringApplication;" >> SpringCloudConfig.java
echo "import org.springframework.boot.autoconfigure.SpringBootApplication;" >> SpringCloudConfig.java
echo "import org.springframework.cloud.config.server.EnableConfigServer;" >> SpringCloudConfig.java
echo " " >> SpringCloudConfig.java
echo "@SpringBootApplication" >> SpringCloudConfig.java
echo "@EnableConfigServer" >> SpringCloudConfig.java
echo "public class SpringCloudConfig {" >> SpringCloudConfig.java
echo " " >> SpringCloudConfig.java 
echo "        public static void main(String[] args) {" >> SpringCloudConfig.java
echo "                SpringApplication.run(SpringCloudConfig.class, args);" >> SpringCloudConfig.java
echo "        }" >> SpringCloudConfig.java
echo "}" >> SpringCloudConfig.java
 
 
 
#cd /opt/spring-cloud-config-server
#sudo ./mvnw spring-boot:run
 
 
#cd /opt/spring-cloud-config-server
cd ../../../../../../../
pwd
#vi Dockerfile
echo "FROM maven:3.3-jdk-8-alpine" > Dockerfile
echo " " >> Dockerfile 
echo "EXPOSE 8980" >> Dockerfile 
echo "COPY . /opt/spring-cloud-config-server/" >> Dockerfile 
echo "WORKDIR /opt/spring-cloud-config-server/" >> Dockerfile 
echo "RUN mvn package" >> Dockerfile 
echo "VOLUME /config" >> Dockerfile 
echo "WORKDIR /" >> Dockerfile 
echo "ENTRYPOINT ["\""java"\"", "\""-Djava.security.egd=file:/dev/./urandom"\"", "\""-jar"\"",\ " >> Dockerfile 
echo "            "\""/opt/spring-cloud-config-server/target/SpringCloudConfig-0.0.1-SNAPSHOT.jar"\"",\ " >> Dockerfile 
echo "            "\""--server.port=8980"\"",\ " >> Dockerfile 
echo "            "\""--spring.config.name=application"\""] " >> Dockerfile 
 
docker build -t api.aigdevopscoe.net:30003/docker/spring-cloud-config-server .

docker login api.aigdevopscoe.net:30003 -u admin -p password
docker push api.aigdevopscoe.net:30003/docker/spring-cloud-config-server

#docker logout


rm -rf spring-cloud-config-server

