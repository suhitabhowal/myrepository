#!/bin/bash

# LOOP THROUGH THE NODES OF THE CLUSTER
for ip in $(kubectl get nodes -owide | awk '/node/{print $6}')
do
    ssh -i $(aws ec2 describe-key-pairs --query 'KeyPairs[?starts_with(KeyName, `kubernetes.aigdevopscoe.net-`) == `true`]' | awk '{print $2}').pem -o "StrictHostKeyChecking no" admin@$ip < /opt/kubernetes/referscript/node-config.sh
done

# ADD SECURITY GROUPS TO NODES
aws ec2 authorize-security-group-ingress --group-id $(aws ec2 describe-security-groups --query 'SecurityGroups[?GroupName == `nodes.aigdevopscoe.net`].{ID:GroupId}') --protocol tcp --port 0-65535 --cidr 0.0.0.0/0

# ADD SECURITY GROUPS TO MASTERS
aws ec2 authorize-security-group-ingress --group-id $(aws ec2 describe-security-groups --query 'SecurityGroups[?GroupName == `masters.aigdevopscoe.net`].{ID:GroupId}') --protocol tcp --port 0-65535 --cidr 0.0.0.0/0
