#!/bin/bash

# LOG INTO THE MACHINE AS ROOT
sudo -i

# SET VARIABLE TO STORE THE DOCKER IMAGE SERVER
DOCKER_IMAGE_SERVER=api.aigdevopscoe.net:30003

# START DOCKER SERVICE
service docker start

# CHECK DOCKER VERSION
docker version

# UPDATE THE daemon.json FILE TO CONTAIN THE DOCKER IMAGE SERVER
echo '{ "insecure-registries":["'$DOCKER_IMAGE_SERVER'"] }' > /etc/docker/daemon.json

# RESTART DOCKER SERVICE
service docker restart
