def label = "mypod-${UUID.randomUUID().toString()}"
// Create pod in kubernetes cluster
podTemplate(label: label, containers: [
    containerTemplate(name: 'maven', image: 'api.aigdevopscoe.net:30003/docker/maven:latest', ttyEnabled: true, command: 'cat')],
    volumes: [ hostPathVolume(mountPath: '/var/run/docker.sock', hostPath: '/var/run/docker.sock')])
{
    node (label)
    {
                container('maven')
                {
                        stage('Fetch from Spring cloud')
                        {
                                // Get the git url from spring cloud
                                sh "curl -s api.aigdevopscoe.net:30008/artifactory-default.json | jq -r '.git.url' > git_url.txt"
                                git_url = readFile('git_url.txt').trim()
                                // Get the sonarqube URL from spring cloud
                                sh "curl -s api.aigdevopscoe.net:30008/artifactory-default.json | jq -r '.sonar.url' > sonar_url.txt"
                                sonar_url = readFile('sonar_url.txt').trim()
                                // Get the artifactory url from spring cloud
                                sh "curl -s api.aigdevopscoe.net:30008/artifactory-default.json | jq -r '.artifactory.url' > artifactory_url.txt"
                                artifactory_url = readFile('artifactory_url.txt').trim()
                                // Get the artifactory url from spring cloud
                                sh "curl -s api.aigdevopscoe.net:30008/artifactory-default.json | jq -r '.vault.url' > vault_url.txt"
                                vault_url = readFile('vault_url.txt').trim()
                        }

                        stage('Checkout SCM')
                        {
                                // Cloning the source code from Gitlab
                                git url: "http://$git_url/test/CustomerMgmt.git",
                                branch: 'master',
                                credentialsId: 'ConnectToCOEGitlab'
                        }

                        stage('Build the application')
                        {
                                // Building the WAR using maven
                                sh 'mvn -v'
                                sh 'mvn clean package'
                        }

                        stage('Perform Soanrqube analysis')
                        {

                                // Running sonarqube analysis
                                sh "mvn sonar:sonar -Dsonar.host.url=http://$sonar_url"
                        }
                        stage('Retrieve secrets in Vault')
                        {
                                // Define Vault Configuration
                                def configuration = [$class: 'VaultConfiguration',
                                vaultUrl: "http://$vault_url",
                                vaultCredentialId: 'Vault_token']
                                // Define the path and vault keys
                                def secrets = [
                                 [$class: 'VaultSecret', path: 'cred/artifactory', secretValues:
                                                 [
                                                   [$class: 'VaultSecretValue', envVar: 'user', vaultKey: 'username'],
                                                   [$class: 'VaultSecretValue', envVar: 'password', vaultKey: 'password']
                                                 ]
                                 ]
                                ]
                        }
                        stage('Create and push image')
                        {
								// Define Vault Configuration
                                def configuration = [$class: 'VaultConfiguration',
                                vaultUrl: "http://$vault_url",
                                vaultCredentialId: 'Vault_token']
                                // Define the path and vault keys
                                def secrets = [
                                 [$class: 'VaultSecret', path: 'cred/artifactory', secretValues:
                                                 [
                                                   [$class: 'VaultSecretValue', envVar: 'user', vaultKey: 'username'],
                                                   [$class: 'VaultSecretValue', envVar: 'password', vaultKey: 'password']
                                                 ]
                                 ]
                                ]
                                // Method to access secrets
                                wrap([$class: 'VaultBuildWrapper', configuration: configuration, vaultSecrets: secrets])
                                {
                                                //Build the docker image
                                                sh "docker build --no-cache -t $artifactory_url/docker/customermgmtapp:latest ."
                                                //Login to artifactory using vault environment variables
                                                sh "docker login -u $user -p $password $artifactory_url"
                                                //Push docker image to artifactory
                                                sh "docker push $artifactory_url/docker/customermgmtapp:latest"
                                }
                        }

                        stage('Deploy the application')
                        {
                                // Deploying the docker image as a service using kubernetes CD plugin
                                // Method to deploy the yaml file
                                kubernetesDeploy (
                                kubeconfigId: 'kubeconfig',
                                configs: 'Application.yml',
                                enableConfigSubstitution: false
                                )
                        }
                }
        }
}

