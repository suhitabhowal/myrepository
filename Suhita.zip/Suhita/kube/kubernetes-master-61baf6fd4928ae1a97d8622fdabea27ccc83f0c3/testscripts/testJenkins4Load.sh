#!/bin/bash
# -------------------- SHELL SCRIPT GENERIC --------------------
echo "Please enter the tota number of jobs to create"
read n

echo "This script would do the below activities:"
echo " 1. Clone an existing job into a series of new ones"
echo " 2. Run all the jobs in parallel"
echo " 3. Delete the newly created jobs"

echo ""
# Parameters for using to do the testing of the Jenkins job
user="admin"
password="admin"
#Jenkin_Mac="ec2-18-220-9-50.us-east-2.compute.amazonaws.com:8080"
Jenkin_Mac=$(kubectl get nodes -owide | awk '/master/{print $6}')
#Port = 8080
Port=31000

existing_job=TestJob
echo "The existing job which is being cloned is: '$existing_job'"

echo 'Get the CRUMB from Jenkins website for authentication:'
echo '## Note: If it gets stuck at the below line, then check the name of the Jenkins master provided above and correct if needed.'
echo "wget -q --auth-no-challenge --user $user --password $password --output-document - 'http://$Jenkin_Mac:$Port/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,"\"":"\"",//crumb)'" > a.txt

#echo "CATTING A.TXT"
#cat a.txt

sudo bash ./a.txt > tmp
#echo "CATTING TMP"
#cat tmp
CRUMB=$(cat tmp)

if [ -z "$CRUMB" ]
then
      echo "Please update the CSRF (Cross Site Request Forgery) under Manage Jenkins -> Configure Global Security "
      return
else
      echo "The crumb got is: $CRUMB"
fi

echo "Take out the config.xml from an existing job:"
echo "curl -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml --u $user:$password -o mylocalconfig.xml"
curl -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml -u $user:$password -o mylocalconfig.xml

echo ""
echo "Create new jobs from the above taken config.xml:"

i=1
while (( $i <= $n  ))
do
    new_job="$existing_job-$i"
    echo "A new job will be created with name: '$new_job'"
	STR_COPY_JOB="curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=$new_job' --data-binary @mylocalconfig.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""
	echo $STR_COPY_JOB > b.txt
	sudo bash ./b.txt
    i=$(( i+1 ))
done

echo ""
echo 'Now that all jobs have been created as needed, run them all:'
echo "TBD:: Yet to run all jobs in parallel"
i=1
while (( $i <= $n  ))
do
    new_job="$existing_job-$i"
    echo "A new job will be created with name: '$new_job'"
	curl -I -X POST http://$Jenkin_Mac:$Port/job/$new_job/build -H "$CRUMB" -u $user:$password
    i=$(( i+1 ))
done

echo "Delete all jobs once all of them have run:"
echo "Do you want to delete all job [y/n]?"
read yn
if "$yn" == "y"
then
	i=1
	while (( $i <= $n  ))
	do
		new_job="$existing_job-$i"
		echo "The job with this name will be deleted: '$new_job'"
		curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/$new_job/doDelete' --user $admin --password $password -H "$CRUMB"
		i=$(( i+1 ))
	done
else
	echo "Not deleting any job"
fi

