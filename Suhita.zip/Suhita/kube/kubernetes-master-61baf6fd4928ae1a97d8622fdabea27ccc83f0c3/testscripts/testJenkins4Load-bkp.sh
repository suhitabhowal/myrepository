echo "This script would do the below activities:"
echo " 1. Clone an existing job into a series of new ones"
echo " 2. Run all the jobs in parallel"
echo " 3. Delete the newly created jobs"

# Parameters for using to do the testing of the Jenkins job
user="admin"
password="admin"
#Jenkin_Mac="ec2-18-220-9-50.us-east-2.compute.amazonaws.com:8080"
Jenkin_Mac="54.184.21.15"
#Port = 8080
Port=30000

echo 'Get the CRUMB from Jenkins website:'
CRUMB=$(wget -q --auth-no-challenge --user $user --password $password --output-document - 'http://$Jenkin_Mac:$Port/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)')

echo 'The crumb got is: $CRUMB'

#echo 'This is to clone job from existing?!:
#curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=TestJob1&mode=copy&from=TestJob' -H "$CRUMB" -u admin:af9473d1b0e09692a42aa1354f744ef7

echo "Take out the config.xml from an existing job:"
curl -X GET http://$Jenkin_Mac:$Port/job/TestJob/config.xml -u admin:admin -o mylocalconfig.xml

echo "Create a new job from the above taken config.xml:"
#curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=TestJob2' --data-binary @mylocalconfig.xml -u admin:af9473d1b0e09692a42aa1354f744ef7 -H "$CRUMB"  -H "Content-Type:text/xml"
curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=TestJob2' --data-binary @mylocalconfig.xml --user $admin --password $password -H "$CRUMB"  -H "Content-Type:text/xml"

echo 'To run a build, from above, copy-paste the $CRUMB value in below:'
curl -I -X POST http://$Jenkin_Mac:$Port/job/TestJob2/build -H "$CRUMB" --user $admin --password $password

echo "Delete the job once it has run:"
#curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/TestJob2/doDelete' -u admin:af9473d1b0e09692a42aa1354f744ef7 -H "$CRUMB"
curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/TestJob2/doDelete' --user $admin --password $password -H "$CRUMB"
