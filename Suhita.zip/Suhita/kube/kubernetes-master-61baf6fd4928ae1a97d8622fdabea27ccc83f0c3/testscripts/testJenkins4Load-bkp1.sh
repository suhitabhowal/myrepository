#!/bin/bash
# -------------------- SHELL SCRIPT GENERIC --------------------
echo "Please enter the tota number of jobs to create"
read n

echo "This script would do the below activities:"
echo " 1. Clone an existing job into a series of new ones"
echo " 2. Run all the jobs in parallel"
echo " 3. Delete the newly created jobs"

echo ""
# Parameters for using to do the testing of the Jenkins job
user="admin"
password="admin"
#Jenkin_Mac="ec2-18-220-9-50.us-east-2.compute.amazonaws.com:8080"
Jenkin_Mac="34.208.15.190"
#Port = 8080
Port=30000

existing_job=TestJob
echo "existing_job is: '$existing_job'"

echo 'Get the CRUMB from Jenkins website:'
echo "wget -q --auth-no-challenge --user $user --password $password --output-document - 'http://$Jenkin_Mac:$Port/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,"\"":"\"",//crumb)'" > a.txt

echo "CATTING A.TXT"
cat a.txt

sudo bash ./a.txt > tmp
echo "CATTING TMP"
cat tmp
CRUMB=$(cat tmp)

if [ -z "$CRUMB" ]
then
      echo "Please update the CSRF (Cross Site Request Forgery) under Manage Jenkins -> Configure Global Security "
      return
else
      echo "The crumb got is: $CRUMB"
fi

echo "Take out the config.xml from an existing job:"
echo "curl -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml --u $user:$password -o mylocalconfig.xml"
curl -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml -u $user:$password -o mylocalconfig.xml

echo ""
echo "Create new jobs from the above taken config.xml:"

i=1
while (( $i <= $n  ))
do
    new_job="$existing_job-$i"
    echo "new_job is: '$new_job'"
	STR_COPY_JOB="curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=$new_job' --data-binary @mylocalconfig.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""
	echo $STR_COPY_JOB > b.txt
	sudo bash ./b.txt
    i=$(( i+1 ))
done

echo ""
echo 'To run a build, from above, copy-paste the $CRUMB value in below:'
curl -I -X POST http://$Jenkin_Mac:$Port/job/$new_job/build -H "$CRUMB" -u $user:$password

